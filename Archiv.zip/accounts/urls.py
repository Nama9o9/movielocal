from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView
from django.urls import path, include

urlpatterns = [
    path('login/', views.MyLoginView.as_view(), name='login'),
    path('signup/', views.MySignUpView.as_view(), name='signup'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('profile/', views.MyProfileView.as_view(), name='profile'),
    path('profile/edit/', views.MyProfileEditView.as_view(), name='profile_edit'),
]
