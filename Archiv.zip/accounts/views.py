from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import MyUserCreationForm
from .models import MyUser
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth.views import LoginView
from .forms import MyUserEditForm

# Create your views here.
class MySignUpView(generic.CreateView):
    form_class = MyUserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'registration/signup.html'

class MyLoginView(LoginView):
    template_name = 'registration/login.html'


class MyProfileView(LoginRequiredMixin, generic.TemplateView):
    template_name = 'profile.html'

class MyProfileEditView(LoginRequiredMixin, generic.UpdateView):
    model = MyUser
    form_class = MyUserEditForm
    template_name = 'registration/profile_edit.html'
    success_url = reverse_lazy('profile')

    def get_object(self):
        return self.request.user
