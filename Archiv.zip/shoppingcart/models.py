from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import models

# Create your models here.
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone
from django.views import generic

from accounts.models import MyUser
from Shop.models import Shop


class ShoppingCart(models.Model):
    timestamp = models.DateTimeField(default=timezone.now)
    myuser = models.ForeignKey(MyUser,
                               on_delete=models.CASCADE,
                               )

    def add_item(myuser, movie):
        # Get existing shopping cart, or create a new one if none exists
        shopping_carts = ShoppingCart.objects.filter(myuser=myuser)
        if shopping_carts:
            shopping_cart = shopping_carts.first()
        else:
            shopping_cart = ShoppingCart.objects.create(myuser=myuser)

        # Add movie to shopping cart
        product_id = movie.id
        product_name = movie.title
                        #+ ' [' + movie.get_fsk_display() + '] [' \
                       #+ movie.genre + '] (' + str(movie.year) + ')')

        price = movie.price
        price = movie.price
        ShoppingCartItem.objects.create(product_id=product_id,
                                        product_name=product_name,
                                        price=price,
                                        quantity=1,
                                        shopping_cart=shopping_cart,
                                        )
    #Anzahl der Artikel in der  ShoppingCart
    def get_number_of_items(self):
        shopping_cart_items = ShoppingCartItem.objects.filter(shopping_cart=self)
        return len(shopping_cart_items)

    #Gesamtpreis berechnen
    def get_total(self):
        total = Decimal(0.0)  # Default without Decimal() would be type float!
        shopping_cart_items = ShoppingCartItem.objects.filter(shopping_cart=self)
        for item in shopping_cart_items:
            total += item.price * item.quantity
        return total


class ShoppingCartItem(models.Model):
    TRANSACTION_CHOICES = [
        ('P', 'Purchase'),
        ('R', 'Rental')
    ]

    product_id = models.IntegerField()
    product_name = models.CharField(max_length=100)
    price = models.DecimalField(decimal_places=2, max_digits=10)
    quantity = models.IntegerField(default=1)
    shopping_cart = models.ForeignKey(ShoppingCart,
                                      on_delete=models.CASCADE,
                                      )
    shop = models.ForeignKey(Shop, on_delete=models.CASCADE, null=True, blank=True)
    transaction_type = models.CharField(max_length=1, choices=TRANSACTION_CHOICES,default='P')
    due_date = models.DateField(null=True, blank=True)

